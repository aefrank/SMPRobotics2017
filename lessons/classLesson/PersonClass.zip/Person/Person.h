/* Person class header file.
 *  By Andrea Frank
 *  7/17/2017
 *  SMP Robotics 2017
 *  
 *  Practice file to introduce SMP students to writing
 *  classes, fields, and methods. Students are instructed
 *	to write the class with public fields for name and 
 *	occupation, private fields for birthdate (day, month,
 *	and year), a public method for introducing themself, 
 *	and a private method for calculating age from birthdate.
 *
*/

#ifndef Person_h
#define Person_h

#include "Arduino.h"	// not automatically included in header files

class Person{
	public:
		/*******************************			FIELDS 				*******************************/
		String personName;
		String occupation;

		/*******************************			CONSTRUCTOR			******************************/	
		/* Creates a new Person object and assigns values to public fields personName and
		* occupation, and private fields _birthDay, _birthMonth, and _birthYear.
		*/
		Person(String personname, String job, int bday, int bmonth, int byear);

		/*******************************			METHODS				*******************************/

		/*		INTRODUCE() 
		*	Prints an introduction of the Person object to the Serial monitor. Requires
		* 	Serial communication to already have been initiated. Introduces name, occupation,
		*	and age. Calculates age with help of private method _calculateAge().
		*	INPUTS: 	- None.
		*	OUTPUTS:	- None.
		*	EFFECTS:	- Prints to Serial Monitor.
		*	REQUIRES: 	- Serial communication to have been set up.
		*/
		void introduce();


	private:
		/*******************************		PRIVATE	FIELDS 				*******************************/
		int _birthDay;
		int _birthMonth;
		int _birthYear;

		/*******************************		PRIVATE	METHODS				*******************************/
		
		/*		_CALCULATEAGE() 
		*	Calculates age of Person object from _birthDay, _birthMonth, and _birthYear, 
		*	given today's date. Helper method for introduce().
		*	INPUTS: 	- int today, int thisMonth, int thisYear;	// Today's date.
		*	OUTPUTS:	- int age;
		*	EFFECTS:	- None.
		*	REQUIRES: 	- None.
		*/
		int _calculateAge(int today, int thisMonth, int thisYear);
};

#endif