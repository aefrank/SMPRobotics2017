/* Person class source file.
 *  By Andrea Frank
 *  7/17/2017
 *  SMP Robotics 2017
 *  
 *  Practice file to introduce SMP students to writing
 *  classes, fields, and methods. Students are instructed
 *	to write the class with public fields for name and 
 *	occupation, private fields for birthdate (day, month,
 *	and year), a public method for introducing themself, 
 *	and a private method for calculating age from birthdate.
 *
*/

#include <Person.h>

	/*******************************			FIELDS 				*******************************/
	// public fields
	String personName;
	String occupation;

	// private fields
	int _birthDay;
	int _birthMonth;
	int _birthYear;

	/*******************************			CONSTRUCTOR			******************************/	
	/* Creates a new Person object and assigns values to public fields personName and
	* occupation, and private fields _birthDay, _birthMonth, and _birthYear.
	*/
	Person::Person(String personname, String job, int bday, int bmonth, int byear){
		personName = personname;
		occupation = job;
		_birthDay = bday;
		_birthMonth = bmonth;
		_birthYear = byear;
	}

	/*******************************			METHODS				*******************************/
	/*		INTRODUCE() 
	*	Prints an introduction of the Person object to the Serial monitor. Requires
	* 	Serial communication to already have been initiated. Introduces name, occupation,
	*	and age. Calculates age with help of private method _calculateAge().
	*	INPUTS: 	- None.
	*	OUTPUTS:	- None.
	*	EFFECTS:	- Prints to Serial Monitor.
	*	REQUIRES: 	- Serial communication to have been set up.
	*/
		void Person::introduce(){
			// calculate age
			int age = _calculateAge(17, 7, 2017);	// today is July 17, 2017	-- note we defined inputs as DAY, MONTH, YEAR

			// print introduction
			Serial.println("Hi, my name is " + personName + ", and I am a " + occupation + ".");
			Serial.print("I am ");
			Serial.print(age);
			Serial.println(" years old.");
			Serial.println();
		}

	/*		_CALCULATEAGE() 
	*	Calculates age of Person object from _birthDay, _birthMonth, and _birthYear, 
	*	given today's date. Helper method for introduce().
	*	INPUTS: 	- int today, int thisMonth, int thisYear;	// Today's date.
	*	OUTPUTS:	- int age;
	*	EFFECTS:	- None.
	*	REQUIRES: 	- None.
	*/
	int Person::_calculateAge(int today, int thisMonth, int thisYear){
		int age;

		// how many years ago was their birth year?
		int yearsAgo = thisYear - _birthYear;

		// has their birthday happened yet?
		if ( thisMonth < _birthMonth ){	// if it is before their birth month, they haven't turned the last year yet
			age = yearsAgo - 1;
		} else if ( thisMonth == _birthMonth ) {		// if it is their birth month, check birth day
			if ( today < _birthDay ) {
				age = yearsAgo - 1;
			}
		} else {	// otherwise, their birthday happened this year, so they are yearsAgo old
			age  = yearsAgo;
		}
		
		return age;
	}







